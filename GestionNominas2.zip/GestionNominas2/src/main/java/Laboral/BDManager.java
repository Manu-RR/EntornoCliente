/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Laboral;

/**
 *
 * @author usuario_
 */
import java.sql.*;
import java.util.*;

public class BDManager {
    private Connection con;

    public BDManager(String url, String user, String pass) throws SQLException {
        con = DriverManager.getConnection(url, user, pass);
    }

    public void insertarEmpleado(Empleado e, Nomina nomina) throws SQLException {
        String sqlEmp = "INSERT INTO Empleados (dni, nombre, sexo, categoria, anyos) VALUES (?, ?, ?, ?, ?)";
        String sqlNom = "INSERT INTO Nominas (dni, sueldo) VALUES (?, ?)";

        try (PreparedStatement psEmp = con.prepareStatement(sqlEmp);
             PreparedStatement psNom = con.prepareStatement(sqlNom)) {
            con.setAutoCommit(false);

            psEmp.setString(1, e.getDni());
            psEmp.setString(2, e.getNombre());
            psEmp.setString(3, String.valueOf(e.getSexo()));
            psEmp.setInt(4, e.getCategoria());
            psEmp.setInt(5, e.getAnyos());
            psEmp.executeUpdate();

            psNom.setString(1, e.getDni());
            psNom.setInt(2, nomina.sueldo(e));
            psNom.executeUpdate();

            con.commit();
        } catch (SQLException ex) {
            con.rollback();
            throw ex;
        } finally {
            con.setAutoCommit(true);
        }
    }

    public List<Empleado> listarEmpleados() throws SQLException, DatosNoCorrectosException {
        List<Empleado> lista = new ArrayList<>();
        String sql = "SELECT * FROM Empleados";
        try (Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) {
                lista.add(new Empleado(
                        rs.getString("nombre"),
                        rs.getString("dni"),
                        rs.getString("sexo").charAt(0),
                        rs.getInt("categoria"),
                        rs.getInt("anyos")));
            }
        }
        return lista;
    }

    public int getSueldo(String dni) throws SQLException {
        String sql = "SELECT sueldo FROM Nominas WHERE dni = ?";
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, dni);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return rs.getInt("sueldo");
        }
        return -1;
    }

    public void actualizarEmpleado(Empleado e, Nomina nomina) throws SQLException {
        String sqlEmp = "UPDATE Empleados SET nombre=?, sexo=?, categoria=?, anyos=? WHERE dni=?";
        String sqlNom = "UPDATE Nominas SET sueldo=? WHERE dni=?";

        try (PreparedStatement psEmp = con.prepareStatement(sqlEmp);
             PreparedStatement psNom = con.prepareStatement(sqlNom)) {
            con.setAutoCommit(false);

            psEmp.setString(1, e.getNombre());
            psEmp.setString(2, String.valueOf(e.getSexo()));
            psEmp.setInt(3, e.getCategoria());
            psEmp.setInt(4, e.getAnyos());
            psEmp.setString(5, e.getDni());
            psEmp.executeUpdate();

            psNom.setInt(1, nomina.sueldo(e));
            psNom.setString(2, e.getDni());
            psNom.executeUpdate();

            con.commit();
        } catch (SQLException ex) {
            con.rollback();
            throw ex;
        } finally {
            con.setAutoCommit(true);
        }
    }
}

