/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Laboral;

import java.util.List;
import java.util.Scanner;

public class CalcularNominas {
    public static void main(String[] args) {
        try {
            // Llama al método que lee desde resources
            List<Empleado> empleados = FicheroEmpleados.leerEmpleados();

            Scanner sc = new Scanner(System.in);
            int opcion;

            do {
                System.out.println("\n--- Menú Nóminas ---");
                System.out.println("1. Listar empleados");
                System.out.println("2. Consultar sueldo por DNI");
                System.out.println("3. Salir");
                System.out.print("Opción: ");
                opcion = sc.nextInt();
                sc.nextLine(); // limpiar buffer

                switch (opcion) {
                    case 1:
                        for (Empleado e : empleados) {
                            System.out.println(e);
                        }
                        break;
                    case 2:
                        System.out.print("Introduce el DNI: ");
                        String dni = sc.nextLine();
                        boolean encontrado = false;
                        for (Empleado e : empleados) {
                            if (e.dni.equalsIgnoreCase(dni)) {
                               
                                System.out.println("Sueldo: " + Nomina.sueldo(e));
                                encontrado = true;
                            }
                        }
                        if (!encontrado) {
                            System.out.println("No existe un empleado con ese DNI.");
                        }
                        break;
                    case 3:
                        System.out.println("Saliendo...");
                        break;
                    default:
                        System.out.println("Opción inválida.");
                }

            } while (opcion != 3);

        } catch (Exception e) {
            System.err.println("Error en la ejecución: " + e.getMessage());
            e.printStackTrace();
        }
    }
}


