package Laboral;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

public class FicheroEmpleados {

    /**
     * Lee el archivo empleados.txt desde resources y devuelve una lista de empleados.
     */
    public static List<Empleado> leerEmpleados() throws Exception {
        // Buscar el archivo en src/main/resources
        InputStream is = FicheroEmpleados.class.getClassLoader().getResourceAsStream("empleados.txt");

        if (is == null) {
            throw new FileNotFoundException("No se encontró empleados.txt en resources");
        }

        List<Empleado> empleados = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                // Formato esperado: Nombre;DNI;Sexo;Categoria;Años
                String[] datos = linea.split(";");
                if (datos.length == 5) {
                    String nombre = datos[0].trim();
                    String dni = datos[1].trim();
                    char sexo = datos[2].trim().charAt(0);
                    int categoria = Integer.parseInt(datos[3].trim());
                    int anyos = Integer.parseInt(datos[4].trim());

                    empleados.add(new Empleado(nombre, dni, sexo, categoria, anyos));
                }
            }
        }
        return empleados;
    }
}

