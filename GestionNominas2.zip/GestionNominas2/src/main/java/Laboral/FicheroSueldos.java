/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Laboral;

/**
 *
 * @author usuario_
 */
import java.io.*;
import java.util.List;

public class FicheroSueldos {

    public static void guardarSueldos(String fichero, List<Empleado> empleados, Nomina nomina)
            throws IOException {
        try (DataOutputStream dos = new DataOutputStream(new FileOutputStream(fichero))) {
            for (Empleado e : empleados) {
                dos.writeUTF(e.getDni());
                dos.writeInt(nomina.sueldo(e));
            }
        }
    }

    public static void leerSueldos(String fichero) throws IOException {
        try (DataInputStream dis = new DataInputStream(new FileInputStream(fichero))) {
            while (true) {
                try {
                    String dni = dis.readUTF();
                    int sueldo = dis.readInt();
                    System.out.println("DNI: " + dni + " → Sueldo: " + sueldo);
                } catch (EOFException eof) {
                    break;
                }
            }
        }
    }
}

